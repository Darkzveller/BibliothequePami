# Move two

This example issues two separate move commands in a single data packet. Both
servos will move to neutral, but servo A will move twice as fast as servo B.

[include, lang:"C++"](../examples/MoveTwo/MoveTwo.ino)
