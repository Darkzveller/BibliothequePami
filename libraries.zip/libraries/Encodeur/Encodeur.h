/*
 * Nom de la bibliothèque : Encodeur
 * Auteur : Quent1-lab
 * Date : 15/12/2023
 * Licence : GNU v3.0
 * Date de la dernière modification : 24/01/2024
 * Version : 1.0.2
 * 
 * Description : Bibliothèque pour la gestion des encodeurs pour un ESP32.
 * 
 * Cette bibliothèque est un logiciel libre ; vous pouvez la redistribuer et/ou
 * la modifier selon les termes de la Licence Publique Générale GNU telle que publiée
 * par la Free Software Foundation ; soit la version 3 de la Licence, ou
 * (à votre discrétion) toute version ultérieure.
 */

#ifndef Encodeur_h
#define Encodeur_h

#include <Arduino.h>
#include "Codeurs.h"

class Encodeur {
  private:
    Codeurs codeurs;
    int32_t oldPositionD;
    int32_t oldPositionG;
    float x;
    float y;
    float theta;
    float rayon;
    float entraxe;
    int reduction;
    int resolution;

    int32_t countG, countD;

  public:
    Encodeur();
    void init();
    void init(float x, float y, float theta, float rayon, float entraxe);
    void init(float x, float y, float theta, float rayon,float entraxe, int reduction, int resolution);
    void change_position(float x, float y, float theta);
    void read();
    int32_t get_countD();
    int32_t get_countG();
    void reset();
    void odometrie();
    void print(int countD,int countG);
    
    float get_x();
    float get_y();
    float get_theta();
    float get_theta_deg();
    int get_resolution();
    int get_reduction();

    int x_to_step(float x);
    int y_to_step(float y);
    int theta_to_step(float theta);
};

#endif
